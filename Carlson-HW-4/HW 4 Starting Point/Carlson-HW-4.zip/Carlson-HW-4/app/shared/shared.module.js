// import { NgModule, ModuleWithProviders } from '@angular/core';
// import { CommonModule } from '@angular/common';
// // import { RatingComponent } from './rating/rating.component';
// import * as Shared from './index';
// @NgModule({
// 	imports: [ Shared.RatingComponent ],
// 	// providers: [ Shared.RatingComponent ],
// 	declarations: [ Shared.RatingComponent ],
// 	exports: [ Shared.RatingComponent ]
// })
// export class SharedModule { 
// 	// static forRoot(): ModuleWithProviders {
// 	// 	return {
// 	// 		ngModule: SharedModule,
// 	// 		providers: [
// 	// 			Shared.RatingComponent
// 	// 		]
// 	// 	};
//   	// }
// } 
//# sourceMappingURL=shared.module.js.map