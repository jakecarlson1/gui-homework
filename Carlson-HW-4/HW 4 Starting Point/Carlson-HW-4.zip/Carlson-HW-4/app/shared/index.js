"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rating_component_1 = require("./rating/rating.component");
exports.RatingComponent = rating_component_1.RatingComponent;
//# sourceMappingURL=index.js.map