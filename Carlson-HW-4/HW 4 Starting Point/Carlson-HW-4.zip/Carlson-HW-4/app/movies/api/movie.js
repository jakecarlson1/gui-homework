"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Movie {
}
exports.Movie = Movie;
//# sourceMappingURL=movie.js.map