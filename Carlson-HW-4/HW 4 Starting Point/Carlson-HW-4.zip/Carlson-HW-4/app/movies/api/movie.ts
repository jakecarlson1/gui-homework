
export class Movie {
    id: number;
    title: string;
    imagePath: string;
    year: number;
    rating: number
}