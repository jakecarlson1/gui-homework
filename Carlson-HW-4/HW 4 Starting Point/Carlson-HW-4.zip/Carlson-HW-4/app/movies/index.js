"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./movies.module"));
__export(require("./movie-list/movie-list.component"));
__export(require("./api/movie"));
__export(require("./api/movie-repository.service"));
//# sourceMappingURL=index.js.map