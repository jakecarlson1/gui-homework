export * from './shared.module';

export * from './pipes/phone.pipe';
