import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'landing',
  templateUrl: 'landing.component.html',
  styleUrls: [ 'landing.component.css' ],
})

export class LandingComponent { 

}