import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { MovieListComponent } from './movie-list/movie-list.component';
import { MovieRepository } from './api/movie-repository.service';

@NgModule({
  imports:      [ 
    BrowserModule,
  ],
  declarations: [
    MovieListComponent,
  ],
  exports: [
      MovieListComponent
  ],
  providers: [
      MovieRepository
  ]
})

export class MoviesModule { }